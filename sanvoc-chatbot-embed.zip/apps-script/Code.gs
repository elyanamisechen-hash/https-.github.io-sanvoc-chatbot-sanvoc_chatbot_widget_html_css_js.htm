function doGet() {
  var html = HtmlService.createHtmlOutputFromFile('index')
    .setTitle('SANVOC Chatbot')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  return html;
}
