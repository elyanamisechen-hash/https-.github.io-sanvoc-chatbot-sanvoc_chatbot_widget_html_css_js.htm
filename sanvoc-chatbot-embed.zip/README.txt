SANVOC Chatbot – Quick Deploy

Two quick ways to get a public URL you can embed in Google Sites:

A) Netlify Drop (fastest, no account needed)
1) Go to https://app.netlify.com/drop
2) Drag-and-drop the file: index.html
3) Netlify gives a public URL like https://glittery-otter-12345.netlify.app
4) In Google Sites: Insert → Embed → By URL → paste that URL.

B) Google Apps Script Web App (Google-hosted URL)
1) Go to https://script.google.com/ and create a new project.
2) Create two files:
   - Code.gs  → paste content from apps-script/Code.gs
   - index.html → paste content from apps-script/index.html
3) Deploy: Deploy → New deployment → Web app
   - Execute as: Me
   - Who has access: Anyone
4) Copy the Web App URL and embed it in Google Sites.

Customize:
- In index.html, at the top script, set BOOKING_LINK, CONTACT_PHONE, CONTACT_EMAIL.
- The widget shows a floating button (bottom-right) to open/close the chat.

